import UIKit
import PhotosUI

final class ViewController: UIViewController, PHPickerViewControllerDelegate {
    private let groupID = "group.com.example.CustomKeyboard"

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        let title = UILabel()
        title.text = "Custom Keyboard"
        title.font = .preferredFont(forTextStyle: .largeTitle)
        title.translatesAutoresizingMaskIntoConstraints = false

        let button = UIButton(type: .system)
        button.setTitle("Choose Keyboard Background", for: .normal)
        button.addTarget(self, action: #selector(chooseImage), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(title)
        view.addSubview(button)

        NSLayoutConstraint.activate([
            title.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            title.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 30)
        ])
    }

    @objc private func chooseImage() {
        var config = PHPickerConfiguration(photoLibrary: .shared())
        config.filter = .images
        config.selectionLimit = 1
        present(PHPickerViewController(configuration: config), animated: true)
    }

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard let provider = results.first?.itemProvider,
              provider.canLoadObject(ofClass: UIImage.self) else { return }

        provider.loadObject(ofClass: UIImage.self) { [weak self] object, _ in
            guard let image = object as? UIImage,
                  let data = image.jpegData(compressionQuality: 0.85),
                  let defaults = UserDefaults(suiteName: self?.groupID ?? "") else { return }

            defaults.set(data, forKey: "keyboardBackground")
        }
    }
}
