# CustomKeyboard

A customizable iOS keyboard extension starter project.

Features:
- Custom keyboard layout with programming/tech keys
- Theme color controls
- Optional custom background image chosen in the host app
- Shared App Group storage between the app and keyboard extension

## Build
Open `CustomKeyboard.xcodeproj` in Xcode, set your Apple Developer Team,
enable the same App Group for both targets, then build/install on an iPhone.

The IPA must be signed with your own Apple development/distribution identity.
