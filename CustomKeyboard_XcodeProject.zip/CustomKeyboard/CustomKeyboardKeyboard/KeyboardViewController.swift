import UIKit

final class KeyboardViewController: UIInputViewController {
    private let groupID = "group.com.example.CustomKeyboard"
    private var backgroundImageView = UIImageView()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        buildKeyboard()
    }

    private func setupBackground() {
        backgroundImageView.contentMode = .scaleAspectFill
        backgroundImageView.clipsToBounds = true
        backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(backgroundImageView)

        NSLayoutConstraint.activate([
            backgroundImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            backgroundImageView.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        if let data = UserDefaults(suiteName: groupID)?.data(forKey: "keyboardBackground") {
            backgroundImageView.image = UIImage(data: data)
        }
    }

    private func buildKeyboard() {
        let keys = [
            ["Q","W","E","R","T","Y","U","I","O","P"],
            ["A","S","D","F","G","H","J","K","L"],
            ["Z","X","C","V","B","N","M"],
            ["{","}","[","]","<",">","/","|","_","~"],
            ["space","return"]
        ]

        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 6
        stack.distribution = .fillEqually
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 6),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -6),
            stack.topAnchor.constraint(equalTo: view.topAnchor, constant: 6),
            stack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -6)
        ])

        for row in keys {
            let rowStack = UIStackView()
            rowStack.axis = .horizontal
            rowStack.spacing = 5
            rowStack.distribution = .fillEqually

            for title in row {
                let button = UIButton(type: .system)
                button.setTitle(title, for: .normal)
                button.titleLabel?.font = .systemFont(ofSize: 17, weight: .medium)
                button.backgroundColor = UIColor.secondarySystemBackground.withAlphaComponent(0.82)
                button.layer.cornerRadius = 7
                button.addTarget(self, action: #selector(keyPressed(_:)), for: .touchUpInside)
                rowStack.addArrangedSubview(button)
            }
            stack.addArrangedSubview(rowStack)
        }
    }

    @objc private func keyPressed(_ sender: UIButton) {
        guard let title = sender.currentTitle else { return }

        if title == "space" {
            textDocumentProxy.insertText(" ")
        } else if title == "return" {
            textDocumentProxy.insertText("\n")
        } else {
            textDocumentProxy.insertText(title)
        }
    }
}
